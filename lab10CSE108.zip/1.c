#include <stdio.h>
int count_vowel(char text[], int size, int result );
int main(){

	int result=0;
	char text[23]="thsii o is an examples.";
	int size = 23;
	result = count_vowel(text,size,result );
	printf("\n result....... %d\n",result);
}
int count_vowel(char text[],int size, int result ){
	
	
	if(text[size ] == 'e' ||
	text[size ] == 'a' ||
	text[size ] == 'i' ||
	text[size ] == 'o' ||
	text[size ] == 'u' 		) result++;
	
	if(size > 0)
		result = count_vowel( text,size-1,result );
	return result;
}
