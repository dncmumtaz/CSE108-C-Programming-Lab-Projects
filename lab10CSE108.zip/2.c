#include <stdio.h>
int max_of_array(int arr[],int size ,int result);
int main(){
	int size = 10;
	int arr[] = {1,21,3,4,55,6,7,88,9,10};
	int  result = arr[size-1];
	result = max_of_array( arr, size , result);
	printf("result..........%d\n",result);
}
int max_of_array(int arr[],int size ,int result){

	if(arr[size] > result){
		result = arr[size];
	}
	if(size > 0)
		result = max_of_array( arr, size-1 , result);
	
	return result;


}

