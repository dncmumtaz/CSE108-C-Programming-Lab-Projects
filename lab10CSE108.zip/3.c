#include <stdio.h>
int Icm(int number1, int number2, int largest);
int main(){
	int number1, number2, largest;

	printf("enter number 0ne and two :");
	scanf("%d",&number1);
	scanf("%d",&number2);
	printf("\n");	
	
	if(number1<number2){
		largest = number1;
	}
	else if(number1>number2)
		largest = number2;
	
	largest = Icm(number1, number2, largest);
	
}
int Icm(int number1, int number2, int largest){

	if( number1<number2){
		largest += number1;
//		printf("****%d****\n",largest);
		
		if(largest %number2 == 0){
			printf("\n number is %d...:",largest);
			printf(" \n");
			return largest;
			}
		else
			largest = Icm(number1, number2, largest);
		
	}
	if( number1>number2){
		largest += number2;
		
		if(largest %number1 == 0){
			printf("\n number is %d...:",largest);
			printf(" \n");
			return largest;
		}	
		else 
			largest = Icm(number1, number2, largest);
	}
}
